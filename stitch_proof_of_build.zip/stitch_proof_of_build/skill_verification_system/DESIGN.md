---
name: Skill-Verification System
colors:
  surface: '#faf8ff'
  surface-dim: '#d2d9f4'
  surface-bright: '#faf8ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f2f3ff'
  surface-container: '#eaedff'
  surface-container-high: '#e2e7ff'
  surface-container-highest: '#dae2fd'
  on-surface: '#131b2e'
  on-surface-variant: '#464555'
  inverse-surface: '#283044'
  inverse-on-surface: '#eef0ff'
  outline: '#777587'
  outline-variant: '#c7c4d8'
  surface-tint: '#4d44e3'
  primary: '#3525cd'
  on-primary: '#ffffff'
  primary-container: '#4f46e5'
  on-primary-container: '#dad7ff'
  inverse-primary: '#c3c0ff'
  secondary: '#855300'
  on-secondary: '#ffffff'
  secondary-container: '#fea619'
  on-secondary-container: '#684000'
  tertiary: '#005338'
  on-tertiary: '#ffffff'
  tertiary-container: '#006e4b'
  on-tertiary-container: '#67f4b7'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#e2dfff'
  primary-fixed-dim: '#c3c0ff'
  on-primary-fixed: '#0f0069'
  on-primary-fixed-variant: '#3323cc'
  secondary-fixed: '#ffddb8'
  secondary-fixed-dim: '#ffb95f'
  on-secondary-fixed: '#2a1700'
  on-secondary-fixed-variant: '#653e00'
  tertiary-fixed: '#6ffbbe'
  tertiary-fixed-dim: '#4edea3'
  on-tertiary-fixed: '#002113'
  on-tertiary-fixed-variant: '#005236'
  background: '#faf8ff'
  on-background: '#131b2e'
  surface-variant: '#dae2fd'
typography:
  headline-xl:
    fontFamily: Geist
    fontSize: 48px
    fontWeight: '700'
    lineHeight: '1.1'
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Geist
    fontSize: 32px
    fontWeight: '600'
    lineHeight: '1.2'
    letterSpacing: -0.01em
  headline-lg-mobile:
    fontFamily: Geist
    fontSize: 24px
    fontWeight: '600'
    lineHeight: '1.2'
  headline-md:
    fontFamily: Geist
    fontSize: 20px
    fontWeight: '600'
    lineHeight: '1.3'
  body-lg:
    fontFamily: Geist
    fontSize: 18px
    fontWeight: '400'
    lineHeight: '1.6'
  body-md:
    fontFamily: Geist
    fontSize: 16px
    fontWeight: '400'
    lineHeight: '1.5'
  label-mono-md:
    fontFamily: JetBrains Mono
    fontSize: 14px
    fontWeight: '500'
    lineHeight: '1.4'
    letterSpacing: 0.02em
  label-mono-sm:
    fontFamily: JetBrains Mono
    fontSize: 12px
    fontWeight: '500'
    lineHeight: '1.4'
    letterSpacing: 0.05em
  button-text:
    fontFamily: Geist
    fontSize: 14px
    fontWeight: '600'
    lineHeight: '1'
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  unit: 4px
  xs: 4px
  sm: 8px
  md: 16px
  lg: 24px
  xl: 48px
  container-margin: 24px
  gutter: 16px
---

## Brand & Style
The design system is built on the philosophy of **Transparent Meritocracy**. It balances the clinical precision required for skill verification with the high-energy pulse of a builder community. The aesthetic is a refined hybrid of **Corporate Modern** and **Developer-Centric Minimalism**, utilizing structured grids and monospaced accents to signal technical authority.

The target audience consists of developers, engineers, and technical recruiters who value signal over noise. The UI should evoke a sense of progress, reliability, and technical proficiency through a clean, high-contrast interface that prioritizes readability and information density.

## Colors
The palette is anchored by **Electric Indigo**, a high-vibrancy blue that represents the technological foundation of the platform. **Amber** serves as the secondary accent, specifically reserved for reputation markers, badges, and "Proof-of-Skill" achievements to provide a warm, high-contrast counterpoint.

- **Primary (Indigo):** Used for primary actions, progress indicators, and active states.
- **Secondary (Amber):** Dedicated to gamification elements, XP, and milestone rewards.
- **Success (Emerald):** Indicates verified status, completed assessments, and positive growth.
- **Reputation (Violet):** A tertiary accent used for high-level social standing or governance roles.
- **Neutrals:** A range of Cool Grays (Slate) ensures the interface feels technical rather than organic.

## Typography
The typography strategy uses **Geist** for its precision and geometric clarity in UI elements and headers. To reinforce the "Proof-of-Skill" developer aesthetic, **JetBrains Mono** is employed for all metadata, tags, code snippets, and achievement scores.

All labels and technical data points should be set in monospace to ensure they are visually distinct from narrative content. Use `headline-xl` sparingly for landing hero sections, while `headline-md` should be the standard for card titles and section headers.

## Layout & Spacing
This design system utilizes an **8px base grid** with a 4px sub-unit for tight technical components. The layout is based on a **12-column fluid grid** for desktop and a **4-column grid** for mobile.

- **Margins:** Standardize on 24px for mobile margins and 48px+ for desktop container padding.
- **Information Density:** High-density layouts are preferred for dashboards, using 8px (sm) and 16px (md) gaps between elements to keep related technical data clustered.
- **Sectioning:** Use vertical rhythm of 48px (xl) between major sections to maintain a sense of openness and high-end polish.

## Elevation & Depth
Depth is achieved through **Tonal Layering** and subtle, tight shadows. Avoid heavy, blurred shadows; instead, use 1px borders in a slightly darker neutral shade combined with "Micro-Shadows" (low blur, low spread) to give the appearance of physical cards sitting on a flat surface.

- **Level 0 (Background):** Surface color #F8FAFC. No shadow.
- **Level 1 (Cards):** Pure white background with a 1px border (#E2E8F0) and a soft 4px blur shadow.
- **Level 2 (Popovers/Dropdowns):** Pure white with a 12px blur shadow and a slightly more prominent border.
- **Active State:** When a component is clicked or active, remove the shadow and shift the background to a subtle indigo tint to simulate "pressing" into the surface.

## Shapes
The design system follows a **Rounded** language (8px to 12px radius) to soften the technical feel and make the platform approachable. 

- **Standard Elements:** Use `rounded-md` (8px) for buttons, input fields, and tags.
- **Containers:** Use `rounded-lg` (16px) for project cards and dashboard widgets.
- **Badges:** Use `rounded-full` (pill-shaped) for status indicators and skill tags to differentiate them from functional UI blocks.

## Components

### Project Cards
Cards should feature a 1px border. The header uses `headline-md` for the title. A footer section should contain Skill Tags and a "Verify" button. Use a 16px padding throughout.

### Skill Tags (Badges)
Tags use **JetBrains Mono** at `label-mono-sm`. They should have a subtle background tint (10% opacity of the primary color) with a solid text color. Skill tags for "Verified" skills should include a small checkmark icon.

### Leaderboard Rows
Rows are designed for high information density. Use a 1px bottom border for separation instead of cards. The "Rank" and "Score" columns must use **JetBrains Mono** to ensure numerical alignment.

### Buttons
- **Primary:** Solid Electric Indigo with white text. High-contrast.
- **Secondary:** White background with a 1px Slate border.
- **Reputation:** Solid Amber background for specific "Claim Achievement" actions.

### Input Fields
Default state uses a Slate-200 border. Focused state switches to a 2px Electric Indigo border with a subtle indigo outer glow (3px blur). Labels always use `label-mono-md` above the field.