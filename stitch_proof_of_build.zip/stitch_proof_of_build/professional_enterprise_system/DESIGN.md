---
name: Professional Enterprise System
colors:
  surface: '#f7f9fb'
  surface-dim: '#d8dadc'
  surface-bright: '#f7f9fb'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f2f4f6'
  surface-container: '#eceef0'
  surface-container-high: '#e6e8ea'
  surface-container-highest: '#e0e3e5'
  on-surface: '#191c1e'
  on-surface-variant: '#44474d'
  inverse-surface: '#2d3133'
  inverse-on-surface: '#eff1f3'
  outline: '#75777e'
  outline-variant: '#c5c6cd'
  surface-tint: '#515f78'
  primary: '#000000'
  on-primary: '#ffffff'
  primary-container: '#0d1c32'
  on-primary-container: '#76849f'
  inverse-primary: '#b9c7e4'
  secondary: '#4f5e80'
  on-secondary: '#ffffff'
  secondary-container: '#c7d7fe'
  on-secondary-container: '#4e5d7e'
  tertiary: '#000000'
  on-tertiary: '#ffffff'
  tertiary-container: '#002019'
  on-tertiary-container: '#00957b'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#d6e3ff'
  primary-fixed-dim: '#b9c7e4'
  on-primary-fixed: '#0d1c32'
  on-primary-fixed-variant: '#39475f'
  secondary-fixed: '#d8e2ff'
  secondary-fixed-dim: '#b6c6ed'
  on-secondary-fixed: '#091b39'
  on-secondary-fixed-variant: '#374767'
  tertiary-fixed: '#5ffbd6'
  tertiary-fixed-dim: '#38debb'
  on-tertiary-fixed: '#002019'
  on-tertiary-fixed-variant: '#005142'
  background: '#f7f9fb'
  on-background: '#191c1e'
  surface-variant: '#e0e3e5'
typography:
  display:
    fontFamily: Hanken Grotesk
    fontSize: 48px
    fontWeight: '700'
    lineHeight: 56px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Hanken Grotesk
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 40px
    letterSpacing: -0.01em
  headline-lg-mobile:
    fontFamily: Hanken Grotesk
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  headline-md:
    fontFamily: Hanken Grotesk
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-sm:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  label-md:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.05em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  unit: 8px
  container-max-width: 1280px
  gutter: 24px
  margin-desktop: 40px
  margin-mobile: 16px
  stack-sm: 8px
  stack-md: 16px
  stack-lg: 32px
---

## Brand & Style

The brand personality is authoritative, precise, and deeply reliable. This design system is engineered for high-stakes environments—fintech, enterprise resource planning, and technical governance—where clarity and trust are paramount. 

The aesthetic follows a **Corporate / Modern** direction with a focus on high-contrast accessibility. It utilizes a deep, nocturnal primary palette contrasted against expansive white space to evoke a sense of stability and institutional strength. The visual language is intentionally restrained, avoiding decorative elements in favor of functional clarity and structured hierarchy.

## Colors

The palette is anchored by the primary color, a deep navy (`#0A192F`), which provides an immediate sense of gravity and professionalism. 

- **Primary & Secondary:** These deep tones are used for critical actions, navigation headers, and primary text to ensure maximum legibility and brand presence.
- **Surface Strategy:** To maintain a high-contrast look, the system uses a tiered white-to-gray scale. Pure white is reserved for cards and input areas, while a light neutral (`#F1F5F9`) defines the background canvas.
- **Borders:** Containers are defined by thin, low-contrast borders for standard grouping, while active states or high-priority elements use the primary color for "strong" borders to guide user focus.

## Typography

This design system employs a dual-font strategy to balance character with utility. **Hanken Grotesk** is used for headlines, providing a sharp, contemporary edge that feels modern yet established. **Inter** is utilized for all body copy and UI labels, chosen for its exceptional legibility in data-dense interfaces and its neutral, systematic tone.

Text scales are strictly adhered to, with larger displays utilizing slightly tighter letter-spacing for a more cohesive "editorial" feel, while smaller labels use increased tracking and uppercase styling to ensure readability at a glance.

## Layout & Spacing

The layout is built on a **fixed-width 12-column grid** for desktop, ensuring content remains centered and readable on large monitors. On mobile, the system transitions to a fluid 4-column layout.

The spacing rhythm is governed by a strict 8px linear scale. Vertical rhythm is maintained through standardized "stack" tokens, ensuring consistent density across different modules. Padding within components is generous to offset the high-contrast color palette, preventing the UI from feeling cramped or overwhelming.

## Elevation & Depth

This design system favors a "flat plus" approach to elevation. Visual hierarchy is primarily established through **Tonal Layers** and **Low-contrast outlines** rather than aggressive shadows.

1.  **Background (Level 0):** Uses the neutral background color (`#F1F5F9`).
2.  **Raised (Level 1):** White surfaces (`#FFFFFF`) with a 1px border (`#E2E8F0`). This is the default state for cards and sections.
3.  **Floating (Level 2):** Used for menus and modals. These elements receive a very soft, high-diffusion shadow (0px 8px 24px rgba(10, 25, 47, 0.08)) and a primary-colored top border to anchor the element.

This approach keeps the interface looking professional and lightweight, avoiding the "heavy" feel of traditional skeuomorphism.

## Shapes

To maintain a professional and serious tone, the design system utilizes **Soft** rounding. 

A base radius of `0.25rem` (4px) is applied to buttons, input fields, and small UI components. Larger containers like cards use `0.5rem` (8px). This subtle rounding takes the edge off the high-contrast borders while maintaining a structured, architectural feel. Circular rounding is reserved exclusively for avatars and status indicators.

## Components

- **Buttons:** Primary buttons use the `#0A192F` background with white text. Secondary buttons use a transparent background with a 1px border in primary navy. Ghost buttons are reserved for tertiary actions and use primary-colored text only.
- **Inputs:** Text fields use a white background, a light gray border, and transition to a 2px primary navy border on focus. Labels are positioned above the field using the `label-md` type scale.
- **Cards:** Cards should be treated as the primary content container. They feature a white background and a subtle 1px border. No shadows are applied unless the card is interactive (e.g., clickable grid items).
- **Chips:** Used for filtering and tagging. These should use a light gray background with primary navy text to ensure they don't compete with primary action buttons.
- **Data Tables:** High-density layouts are a core part of this system. Header rows should be slightly tinted with the neutral background color, utilizing bold `body-sm` text for column identifiers.